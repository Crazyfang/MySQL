CREATE PROCEDURE UP_GetRecordByPage(IN tablename  VARCHAR(255), IN fldName VARCHAR(255), IN sCondition VARCHAR(500),
                                    IN orderField VARCHAR(100), IN orderType INT, IN primaryField VARCHAR(100),
                                    IN pageIndex  INT, IN pagesize INT)
  BEGIN
	    DECLARE sTemp  VARCHAR(1000);
	    DECLARE sSql   VARCHAR(4000);
	    DECLARE sOrder VARCHAR(1000);
	    
	    IF orderType = 1 THEN
		SET sOrder = CONCAT(' order by ', orderField, ' desc ');
		SET sTemp  = '<(select min';
	    ELSE
		SET sOrder = CONCAT(' order by ', orderField, ' asc ');
		SET sTemp  = '>(select max';
	    END IF;
	    
	    IF pageIndex = 1 THEN
		IF sCondition <> '' THEN
		    SET sSql = CONCAT('select ', fldName, ' from ', tablename, ' where ');
		    SET sSql = CONCAT(sSql, sCondition, sOrder, ' limit ?');
		ELSE
		    SET sSql = CONCAT('select ', fldName, ' from ', tablename, sOrder, ' limit ?');
		END IF;
	    ELSE
		IF sCondition <> '' THEN
		    SET sSql = CONCAT('select ', fldName, ' from ', tablename);
		    SET sSql = CONCAT(sSql, ' where ', sCondition, ' and ', primaryField, sTemp);
		    SET sSql = CONCAT(sSql, '(', primaryField, ')', ' from (select ');
		    SET sSql = CONCAT(sSql, ' ', primaryField, ' from ', tablename, sOrder);
		    SET sSql = CONCAT(sSql, ' limit ', (pageIndex-1)*pagesize, ') as tabtemp)', sOrder);
		    SET sSql = CONCAT(sSql, ' limit ?');
		ELSE
		    SET sSql = CONCAT('select ', fldName, ' from ', tablename);
		    SET sSql = CONCAT(sSql, ' where ', primaryField, sTemp);
		    SET sSql = CONCAT(sSql, '(', primaryField, ')', ' from (select ');
		    SET sSql = CONCAT(sSql, ' ', primaryField, ' from ', tablename, sOrder);
		    SET sSql = CONCAT(sSql, ' limit ', (pageIndex-1)*pagesize, ') as tabtemp)', sOrder);
		    SET sSql = CONCAT(sSql, ' limit ?');
		END IF;
	    END IF;
	    SET @ipageSize = pagesize;
	    SET @sQuery = sSql;
	    PREPARE stmt FROM @sQuery;
	    EXECUTE stmt USING @iPageSize;
    END;
